var Demonixis = window.Demonixis || {};
Demonixis.GameHelper = Demonixis.GameHelper || {};

// LevelHelper to handle level progression and end-game state
Demonixis.GameHelper.LevelHelper = function(start, end) {
    this.current = start || 1;  // Current level starts at 1
    this.next = this.current + 1;  // Next level
    this.count = end || 3;  // Number of total levels (3 by default)
    this.isFinished = false;  // Track if the game is finished

    // Function to get the next level
    this.getNext = function() {
        if (this.next > this.count) {
            this.isFinished = true;
            displayWinScreen();  // Show the win screen after completing all levels
        } else {
            this.current = this.next;  // Progress to the next level
            this.next++;
        }
        return this.current;
    };
};

// CameraHelper to handle camera movements in the 3D maze
Demonixis.GameHelper.CameraHelper = function(camera) {
    this.translation = 5;
    this.rotation = 0.035;
    this.origin = {
        position: {
            x: 0,
            y: 0,
            z: 0,
            mapX: 0,
            mapY: 0,
            mapZ: 0
        },
        x: 0,
        y: 0,
        z: 0
    };
    
    this.camera = camera;
};

// Function to display the winning screen after completing all levels
function displayWinScreen() {
    const winOverlay = document.getElementById('win-overlay');
    winOverlay.style.display = 'flex';  // Show the win overlay when the game is finished

    // Optional: Add any additional logic or animations for the win screen
    console.log("Game completed! Showing win screen.");
}

// Example function to trigger level completion and progression
function levelCompleted() {
    const levelHelper = new Demonixis.GameHelper.LevelHelper(1, 3);  // Start at level 1, end at level 3
    levelHelper.getNext();
}
