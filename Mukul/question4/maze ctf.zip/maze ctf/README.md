
# 3D-Maze-Game
A 3D Maze Game made using ThreeJs and WebGL

![ss1](https://user-images.githubusercontent.com/64016811/119042625-b7ef0680-b9d5-11eb-896a-24f94212b896.jpg)

![ss2](https://user-images.githubusercontent.com/64016811/119042632-b9b8ca00-b9d5-11eb-95a1-6b42d962dff2.jpg)
